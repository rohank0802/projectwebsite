// Loader with Enhanced Timeout Fallback
function hideLoader() {
  const loader = document.getElementById("loader");
  if (loader) {
    loader.style.display = "none";
  }
}

window.addEventListener("load", () => {
  hideLoader();
  console.log("Page fully loaded.");
});

setTimeout(() => {
  hideLoader();
  console.warn("Loader fallback triggered: Page load event not completed.");
}, 5000);

// 3D Tech Background
try {
  if (typeof THREE !== "undefined") {
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById("tech-bg"), alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);

    const particlesGeometry = new THREE.BufferGeometry();
    const particlesCount = 500;
    const posArray = new Float32Array(particlesCount * 3);

    for (let i = 0; i < particlesCount * 3; i++) {
      posArray[i] = (Math.random() - 0.5) * 100;
    }

    particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    const particlesMaterial = new THREE.PointsMaterial({
      color: 0xff6347,
      size: 0.3,
      transparent: true,
      blending: THREE.AdditiveBlending,
    });
    const particlesMesh = new THREE.Points(particlesGeometry, particlesMaterial);
    scene.add(particlesMesh);
    camera.position.z = 20;

    let animationFrameId;
    function animate() {
      animationFrameId = requestAnimationFrame(animate);
      particlesMesh.rotation.y += 0.002;
      renderer.render(scene, camera);
    }
    animate();

    window.addEventListener("unload", () => {
      cancelAnimationFrame(animationFrameId);
      renderer.dispose();
    });
  } else {
    console.warn("Three.js not loaded; skipping 3D background.");
    hideLoader();
  }
} catch (error) {
  console.error("Error initializing 3D background:", error);
  hideLoader();
}

// WhatsApp
document.getElementById("whatsapp-icon").addEventListener("click", () => {
  window.open("https://wa.me/919592601467", "_blank");
});

// Lightbox for Projects
const thumbnails = document.querySelectorAll(".project-thumbnail");
const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightboxImage");
const closeLightbox = document.getElementById("closeLightbox");

thumbnails.forEach(thumbnail => {
  thumbnail.addEventListener("click", () => {
    const fullImage = thumbnail.getAttribute("data-full");
    lightboxImage.src = fullImage;
    lightbox.style.display = "flex";
  });
});

closeLightbox.addEventListener("click", () => {
  lightbox.style.display = "none";
});

// Navbar Auto-Close
const navbarToggler = document.querySelector(".navbar-toggler");
const navbarCollapse = document.querySelector(".navbar-collapse");
document.querySelectorAll(".nav-link").forEach(link => {
  link.addEventListener("click", () => {
    if (navbarCollapse.classList.contains("show")) {
      navbarToggler.click();
    }
  });
});

// Payment Handling
let selectedAmount = 0;

function openPaymentDetailsForm(amount) {
  selectedAmount = amount;
  document.getElementById("payment-details-form").style.display = "flex";
}

function closePaymentDetailsForm() {
  document.getElementById("payment-details-form").style.display = "none";
}

// Razorpay Configuration
const razorpayConfig = {
  key: "rzp_test_X9Wic3icEjPfMd", // Replace with your Razorpay key
  currency: "INR",
  name: "Decent11 Innovation Pvt Ltd",
  description: "Payment for Plan",
  image: "https://your-logo-url.com/logo.png", // Replace with your logo URL
  handler: function (response) {
    const name = document.getElementById("customerName").value.trim();
    const email = document.getElementById("customerEmail").value.trim();
    const phone = document.getElementById("customerPhone").value.trim();
    const address = document.getElementById("customerAddress").value.trim();
    const service = document.getElementById("selectedService").value;

    sendPaymentDetails(name, email, phone, address, service, "Razorpay", response.razorpay_payment_id, "Successful");
    showPaymentSuccess("Razorpay", response.razorpay_payment_id);
  },
  prefill: {
    name: document.getElementById("customerName")?.value || "",
    email: document.getElementById("customerEmail")?.value || "",
    contact: document.getElementById("customerPhone")?.value || "",
  },
  theme: {
    color: "#2196F3",
  },
};

function proceedToRazorpay() {
  const name = document.getElementById("customerName").value.trim();
  const email = document.getElementById("customerEmail").value.trim();
  const phone = document.getElementById("customerPhone").value.trim();
  const address = document.getElementById("customerAddress").value.trim();
  const service = document.getElementById("selectedService").value;

  if (!name || !email || !phone || !address || !service) {
    alert("Please fill in all fields.");
    return;
  }

  document.getElementById("payment-details-form").style.display = "none";

  razorpayConfig.amount = selectedAmount * 100; // Convert to paise
  razorpayConfig.description = `Payment for ${getPlanName(selectedAmount)} Plan`;
  razorpayConfig.prefill.name = name;
  razorpayConfig.prefill.email = email;
  razorpayConfig.prefill.contact = phone;

  const razorpay = new Razorpay(razorpayConfig);
  razorpay.open();
}

function proceedToUPI() {
  const name = document.getElementById("customerName").value.trim();
  const email = document.getElementById("customerEmail").value.trim();
  const phone = document.getElementById("customerPhone").value.trim();
  const address = document.getElementById("customerAddress").value.trim();
  const service = document.getElementById("selectedService").value;

  if (!name || !email || !phone || !address || !service) {
    alert("Please fill in all fields.");
    return;
  }

  document.getElementById("payment-details-form").style.display = "none";

  const upiId = "9142875151@kotak"; // Replace UPI ID
  const upiUrl = `upi://pay?pa=${upiId}&pn=Decent11%20Innovation&am=${selectedAmount}&cu=INR&tn=Payment%20for%20${encodeURIComponent(service)}`;

  try {
    window.location.href = upiUrl;
    setTimeout(() => {
      showUPIVerification(name, email, phone, address, service);
    }, 2000);
  } catch (error) {
    console.error("UPI redirect failed:", error);
    showPaymentFailed("UPI", null);
  }
}

function getPlanName(amount) {
  switch (amount) {
    case 5000: return "Basic";
    case 10000: return "Pro";
    case 15000: return "Premium";
    default: return "Unknown";
  }
}

function sendPaymentDetails(name, email, phone, address, service, method, transactionId, status) {
  const formData = new FormData();
  formData.append("name", name);
  formData.append("email", email);
  formData.append("phone", phone);
  formData.append("address", address);
  formData.append("service", service);
  formData.append("amount", selectedAmount);
  formData.append("payment_method", method);
  formData.append("transaction_id", transactionId || "N/A");
  formData.append("payment_status", status);

  fetch("https://formspree.io/f/xkgjwayg", {
    method: "POST",
    body: formData,
    headers: { Accept: "application/json" }
  })
    .then(response => {
      if (!response.ok) throw new Error("Failed to send payment details.");
      console.log(`${method} payment details sent to Formspree: ${status}`);
    })
    .catch(error => console.error(`Error sending ${method} payment details:`, error));
}

function showPaymentSuccess(method, transactionId) {
  const modal = document.getElementById("payment-success");
  modal.innerHTML = `
    <div class="modal-content" style="text-align: center; padding: 20px; max-width: 400px;">
      <i class="fas fa-check-circle" style="color: #28a745; font-size: 40px; margin-bottom: 10px; animation: tickPulse 1s ease-in-out; text-shadow: 0 0 10px rgba(40, 167, 69, 0.5);"></i>
      <h3 style="color: #ffd700; font-size: 1.5rem; margin-bottom: 10px;">Payment Successful</h3>
      <p style="color: #ddd; font-size: 0.9rem;">Thank you! Your payment via ${method} was successful.<br>Transaction ID: ${transactionId || "N/A"}<br>Redirecting to home in 5 seconds...</p>
    </div>
  `;
  modal.style.display = "flex";

  setTimeout(() => {
    modal.style.display = "none";
    window.location.href = "#home";
  }, 5000);
}

function showPaymentFailed(method, transactionId) {
  const modal = document.getElementById("payment-success");
  modal.innerHTML = `
    <div class="modal-content" style="text-align: center; padding: 20px; max-width: 400px;">
      <i class="fas fa-times-circle" style="color: #dc3545; font-size: 40px; margin-bottom: 10px;"></i>
      <h3 style="color: #ffd700; font-size: 1.5rem; margin-bottom: 10px;">Payment Failed</h3>
      <p style="color: #ddd; font-size: 0.9rem;">Your payment via ${method} could not be processed.<br>Transaction ID: ${transactionId || "N/A"}<br>Closing in 5 seconds...</p>
    </div>
  `;
  modal.style.display = "flex";

  setTimeout(() => {
    modal.style.display = "none";
  }, 5000);
}

function showUPIVerification(name, email, phone, address, service) {
  const modal = document.getElementById("payment-success");
  modal.innerHTML = `
    <div class="modal-content" style="text-align: center; padding: 20px; max-width: 400px;">
      <i class="fas fa-info-circle" style="color: #2196F3; font-size: 40px; margin-bottom: 10px;"></i>
      <h3 style="color: #ffd700; font-size: 1.5rem; margin-bottom: 10px;">UPI Payment Verification</h3>
      <p style="color: #ddd; font-size: 0.9rem;">Please enter your UPI Transaction ID after completing the payment:</p>
      <input type="text" id="upiTransactionId" class="form-control mt-2" placeholder="Enter Transaction ID" required>
      <div class="mt-3">
        <button class="btn btn-success btn-xs" onclick="confirmUPISuccess('${name}', '${email}', '${phone}', '${address}', '${service}')">Payment Successful</button>
        <button class="btn btn-danger btn-xs" onclick="confirmUPIFailure('${name}', '${email}', '${phone}', '${address}', '${service}')">Payment Failed</button>
      </div>
    </div>
  `;
  modal.style.display = "flex";
}

function confirmUPISuccess(name, email, phone, address, service) {
  const transactionId = document.getElementById("upiTransactionId").value.trim();
  if (!transactionId) {
    alert("Please enter a valid Transaction ID.");
    return;
  }
  sendPaymentDetails(name, email, phone, address, service, "UPI", transactionId, "Successful");
  showPaymentSuccess("UPI", transactionId);
}

function confirmUPIFailure(name, email, phone, address, service) {
  sendPaymentDetails(name, email, phone, address, service, "UPI", null, "Failed");
  showPaymentFailed("UPI", null);
}

// Contact Form Submission
const contactForm = document.querySelector(".contact-form");
if (contactForm) {
  contactForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const formData = new FormData(contactForm);
    fetch("https://formspree.io/f/xkgjwayg", {
      method: "POST",
      body: formData,
      headers: { Accept: "application/json" }
    })
      .then(response => {
        if (response.ok) {
          const successModal = document.createElement("div");
          successModal.className = "modal";
          successModal.id = "contact-success";
          successModal.innerHTML = `
            <div class="modal-content" style="text-align: center; padding: 20px; max-width: 400px;">
              <i class="fas fa-check-circle" style="color: #28a745; font-size: 40px; margin-bottom: 10px; animation: tickPulse 1s ease-in-out;"></i>
              <h3 style="color: #ffd700; font-size: 1.5rem; margin-bottom: 10px;">Message Sent</h3>
              <p style="color: #ffd700; font-size: 1rem;">Your message has been sent successfully. We will contact you soon!</p>
            </div>
          `;
          document.body.appendChild(successModal);
          successModal.style.display = "flex";
          contactForm.reset();
          setTimeout(() => {
            successModal.style.display = "none";
            successModal.remove();
          }, 5000);
        } else {
          throw new Error("Form submission failed");
        }
      })
      .catch(error => {
        console.error("Error:", error);
        alert("There was an issue sending your message. Please try again.");
      });
  });
}

// Counter Animation
function animateCounter() {
  const counters = document.querySelectorAll(".counter");
  counters.forEach(counter => {
    const target = +counter.getAttribute("data-target");
    let count = 0;
    const updateCounter = () => {
      const increment = target / 100;
      if (count < target) {
        count += increment;
        counter.textContent = Math.ceil(count);
        setTimeout(updateCounter, 20);
      } else {
        counter.textContent = target;
      }
    };
    updateCounter();
  });
}

window.addEventListener("scroll", () => {
  const facts = document.getElementById("company-facts");
  if (facts && facts.getBoundingClientRect().top <= window.innerHeight) {
    animateCounter();
    window.removeEventListener("scroll", this);
  }

  const backToTopButton = document.getElementById("back-to-top");
  if (window.scrollY > 300) {
    backToTopButton.style.display = "block";
  } else {
    backToTopButton.style.display = "none";
  }
});

// Scroll to Top
function scrollToTop() {
  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
}

// CSS Animation for Realistic Tick
const style = document.createElement("style");
style.innerHTML = `
  @keyframes tickPulse {
    0% { transform: scale(0.8); opacity: 0; }
    50% { transform: scale(1.1); opacity: 1; }
    100% { transform: scale(1); opacity: 1; }
  }
`;
document.head.appendChild(style);

console.log("Script loaded successfully.");