// success.js
document.addEventListener("DOMContentLoaded", () => {
  const urlParams = new URLSearchParams(window.location.search);
  const paymentStatus = urlParams.get("payment");
  const transactionId = urlParams.get("txn_id");

  if (paymentStatus === "success" && transactionId) {
    const modal = document.createElement("div");
    modal.className = "modal";
    modal.id = "payment-success";
    modal.innerHTML = `
      <div class="modal-content" style="text-align: center;">
        <i class="fas fa-check-circle" style="color: #28a745; font-size: 50px; margin-bottom: 15px; animation: tickPulse 1s ease-in-out; text-shadow: 0 0 10px rgba(40, 167, 69, 0.5);"></i>
        <h3>Payment Successful</h3>
        <p>Thank you! Your payment via Razorpay was successful.<br>Transaction ID: ${transactionId}<br>Redirecting to home in 5 seconds...</p>
      </div>
    `;
    document.body.appendChild(modal);
    modal.style.display = "flex";

    setTimeout(() => {
      modal.style.display = "none";
      window.location.href = "#home";
    }, 5000);
  }

  // CSS Animation for Realistic Tick
  const style = document.createElement("style");
  style.innerHTML = `
    @keyframes tickPulse {
      0% { transform: scale(0.8); opacity: 0; }
      50% { transform: scale(1.1); opacity: 1; }
      100% { transform: scale(1); opacity: 1; }
    }
  `;
  document.head.appendChild(style);
});