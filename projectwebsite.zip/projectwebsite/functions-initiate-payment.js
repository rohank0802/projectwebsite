const axios = require("axios");
const crypto = require("crypto");

exports.handler = async (event) => {
  const { amount, orderId, customerId, email, phone } = JSON.parse(event.body);

  const merchantId = "gPbMTW86861811518736"; // Your Merchant ID
  const merchantKey = "YOUR_MERCHANT_KEY"; // Replace with your Paytm Merchant Key
  const paytmHost = "https://securegw-stage.paytm.in"; // Use "https://securegw.paytm.in" for production

  const body = {
    requestType: "Payment",
    mid: merchantId,
    websiteName: "WEBSTAGING", // Use "DEFAULT" for production
    orderId: orderId,
    callbackUrl: "https://your-netlify-site.netlify.app/.netlify/functions/verify-payment",
    txnAmount: { value: amount.toString(), currency: "INR" },
    userInfo: { custId: customerId, email: email, mobile: phone }
  };

  const checksum = generateChecksum(JSON.stringify(body), merchantKey);
  const headers = {
    "Content-Type": "application/json",
    "checksumhash": checksum
  };

  try {
    const response = await axios.post(`${paytmHost}/theia/api/v1/initiateTransaction?mid=${merchantId}&orderId=${orderId}`, body, { headers });
    if (response.data && response.data.body && response.data.body.txnToken) {
      return {
        statusCode: 200,
        body: JSON.stringify({ success: true, token: response.data.body.txnToken })
      };
    } else {
      return {
        statusCode: 500,
        body: JSON.stringify({ success: false, error: "Failed to get transaction token" })
      };
    }
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, error: error.message })
    };
  }
};

function generateChecksum(body, key) {
  const salt = crypto.randomBytes(4).toString("hex");
  const data = body + "|" + salt;
  const hash = crypto.createHmac("sha256", key).update(data).digest("hex");
  return hash + salt;
}