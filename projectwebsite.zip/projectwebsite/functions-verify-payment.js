const axios = require("axios");
const crypto = require("crypto");

exports.handler = async (event) => {
  const { orderId } = JSON.parse(event.body);

  const merchantId = "gPbMTW86861811518736"; // Your Merchant ID
  const merchantKey = "gPbMTW86861811518736"; // Replace with your Paytm Merchant Key
  const paytmHost = "https://securegw-stage.paytm.in"; // Use "https://securegw.paytm.in" for production

  const body = {
    mid: merchantId,
    orderId: orderId
  };

  const checksum = generateChecksum(JSON.stringify(body), merchantKey);
  const headers = {
    "Content-Type": "application/json",
    "checksumhash": checksum
  };

  try {
    const response = await axios.post(`${paytmHost}/v3/order/status`, body, { headers });
    const data = response.data.body;
    if (data.resultInfo.resultStatus === "TXN_SUCCESS") {
      return {
        statusCode: 200,
        body: JSON.stringify({ success: true, status: "TXN_SUCCESS" })
      };
    } else {
      return {
        statusCode: 200,
        body: JSON.stringify({ success: false, status: data.resultInfo.resultStatus })
      };
    }
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, error: error.message })
    };
  }
};

function generateChecksum(body, key) {
  const salt = crypto.randomBytes(4).toString("hex");
  const data = body + "|" + salt;
  const hash = crypto.createHmac("sha256", key).update(data).digest("hex");
  return hash + salt;
}